package adt.linkedList;


public class SingleLinkedListImpl<T> implements LinkedList<T> {

	protected SingleLinkedListNode<T> head;

	public SingleLinkedListImpl() {
		this.head = new SingleLinkedListNode<T>();
	}

	@Override
	public boolean isEmpty() {
		return (this.head.isNIL());
	}

	@Override
	public int size() {
		Integer result = 0;
		
		if(!isEmpty()) {
			SingleLinkedListNode<T> node = this.head;
			
			while(!node.isNIL()) {
				result++;
				node = node.getNext();
			}
		}
		
		return result;
	}

	@Override
	public T search(T element) {
		SingleLinkedListNode<T> node = this.head;
		
		while(!node.isNIL() && !node.getData().equals(element)) {
			node = node.getNext();
		}
		
		return node.getData();
	}

	@Override
	public void insert(T element) {
		if(this.head.isNIL()) {
			SingleLinkedListNode<T> newHead = new SingleLinkedListNode<T>(element, this.head);
			this.head = newHead;
			return;
		}
		
		SingleLinkedListNode<T> node = this.head;
		
		while(!node.getNext().isNIL()) {
			node = node.getNext();
		}
		
		SingleLinkedListNode<T> newNode = new SingleLinkedListNode<T>(element, node.getNext());
		node.setNext(newNode);
	}

	@Override
	public void remove(T element) {
		// TODO Auto-generated method stub
		throw new UnsupportedOperationException("Not implemented!");
	}

	@Override
	public T[] toArray() {
		// TODO Auto-generated method stub
		throw new UnsupportedOperationException("Not implemented!");
	}

	public SingleLinkedListNode<T> getHead() {
		return head;
	}

	public void setHead(SingleLinkedListNode<T> head) {
		this.head = head;
	}

}
